package internal

import "os"

var (
	FilePerm os.FileMode = 0o777
	DirPerm  os.FileMode = 0o777
)
